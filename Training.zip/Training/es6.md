# Variable declaration
## Let
Before es6, _*var*_ is used to as global variable in javascipt
In ES6, wwe have _let_ and _const_
_let_ is used to in block scope
For example,
```
funtion Foo(){
    let foo = 'foo'
    console.log(foo)
}
Foo()
console.log(foo)
```

The output of terminal will be that 

```
foo
foo is not undefined

```
## const
_const_ is used to initialize global variable

```
const Foo = 'FOO'

```
# Arrow function


For example, 

```
let myArray = [1,2,3,4,5]
let result = myArray.filter(e => e>2)
````
# Parameter Hanling

## Default parameter 

```
let sum = (a =0, b=0) => {
    return a +b 
}
```

## Rest parameters
Aggregation of remaining arguments into single parameter of variadic functions.

```
let  foo = (x,y,..a) {
    return (x + y) * a.length
}

foo(1,2,3,5,7) === 9 (true)
```


## Spread Operator 
Spreading of elements of an iterable collection (like an array or even a string) into both literal elements and individual function parameters.

For example 

```
var myPrams = [3,5,7]
let  foo = (x,y,..a) {
    return (x + y) * a.length
}

foo(1,2,myParams) === 9 (true)

```

# Template Literals

```
let firstName = 'Hai'
let lastName = 'Dinh'

console.log('My full name is ${firstName} ${lastName}')

```

# Enhaced Object Property
## Propert Shorthand

```
let firstName = 'Hai'
let lastName = 'Dinh'

fullName = { firstName, lastName } 

```

## Method Properties 

```
obj = {
    foo(a,b) {

    },
    bar(c,d) {

    }
 }

 ```

 # Destructuring Assignment
 ## Array matching

```
 let list = [1,2,3]
 let [foo, ,bar] = list (will be [1,3])
```
## Object Matching 

```
let student = { name: 'foo', grade: 'bar' }
let { name, grade } = student
```

## Object Matching, Deep Matching

```
let student = { name: 'foo', grade: 'bar' }
let { name: studentName, grade: studentGrade } = student
```

## Default value in object matching and array matching
```
let student = { name: 'foo' }
let { name, grade = 6 } = student

let myArray =[1]
let [x,y = 2 ] = myArray
```

## Parameter Matching

``` 
    function displayStudentInfo({ name, grade }) {
        console.log('Name is ${name} and grade is ${grade}')

    function displayStudent({ name: n, grade: g}) {
         console.log('Name is ${n} and grade is ${g}')
    }

    function displayMyArr([firstEle, seconedEle,, ForthEle]) {
        console.log(firstEle, seconedEle,, ForthEle)
    }
}
```
# Modules

## Import/Export

```
//  Helper/Math.js

export const PI = 3.14

export function calRectangularArea(x){
    return x*x
}

// App/Http/Controllers/ShapeController.js

import * from 'Helper/Math.js'
// or use destructuring 

import { PI, calRecangtularArea } from 'Helper/Math.js'
```
# Class
## Class Definition

```
class People {
    constructor(name,age){
        this.name = name
        this.age = age
    }
    displayInfo(){
        console.log('Name is ${name} and age is {$age}')
    }
} 
```

## Class Inheritance

```
import People from './People.js'

class Student extends People{
    constructor(name,age,grade) {
        super(name,age)
        this.grade = grade
    }
}
```

## Getter, Setter
```
class People {
    constructor(name,age){
        this.name = name
        this.age = age
    }
    displayInfo(){
        console.log('Name is ${name} and age is {$age}')
    }
    getName(){
        return this.name
    }
    setName(name) {
        this.name = name 
    }
} 
```
# Map/Set
## Set
```
let mySet = new Set()
smySetet.add("hi)
mySet.add("hello)
mySet.size === 2 (true)
mySet.has("hi") === true
```

## Map 
```
let myMap = new Map()
myMap.set("name", "Hai")
myMap.set("age", 22)

myMap.size ===2
myMap.get("age") === 22
```

## WeakMap/WeakSet

# New Built-in Metohd
## Object Assign
```
let des ={ foo: 1 }
let temp = { bar: 2 }
Object.assign(des,temp)
// now des = { foo:1, bar:2 }
```
## Finding Element Array
```
[1,2,3,4,5].find(e => e>4)
```
## String repeating
```
"foo".repeat(3)
```
## String searching
```
"Gemini".includes("mini") (true)
"Gemini".includes("mini",2) (true)
"Gemini".includes("mini",4) (false)
```
_Besides, there are some new methods like number type checking, number safety checking, number comparaiosn, and number truncation_

# Promise 
```
let PromiseExample = (name) => {
    return new Promise(resolve, reject) {
        setTimeout(() => {
            reolve(name)
        },1000)
    }
}
PromiseExample("HaiDV7).then((name) => {
    console.log(My name is ${name})
} 
```
## Promise Combination

It includes new method. They are Promise.all() and Promise.race()
In this section, I will explain Promise.all()

```
function getRandomName(url){
    return new Promise(resolve,reject) {
        axios.get(url).then(res => {
            resolve(res)
        }).catch((err) =>{
            reject(err)
        })
    }
}

Promise.all([
    getRandomName('http://localhost/get-random-name);
    getRandomName('http://localhost/get-random-string);
]).then((data) => {
    let [name1, name2] = data
})
```

# Proxying 
Hooking into runtime-level object meta-opertion

Example for hooking to set value
```
const obj = {};

const handler = {
  set(target, key, value) {
    console.log('Setting value ${key} as ${value}')
    target[key] = value;
  },
};

const p = new Proxy(obj, handler);
p.a = 10; // logs "Setting value a as 10"
p.c = 20; // logs "Setting value c as 20"
console.log(p.a); // logs 10
```

Example to hook in get value
```
const obj = {a: 10, c: 20};

const handler = {
  get(target, key) {
    console.log('Reading value from ${key}')
    return target[key];
  },
};

const p = new Proxy(obj, handler);
console.log(p.a); // logs "Reading value from a" and "10"
```





