# Async/Await
## Prerequisites
- Undestand asynchnorous in Javascipt
- Understand Promise 
## Purpose:
Although Promisse can handle asynchonorous tasks, it can lead to Promise hell. This is the reason why we have Async/Await
## Usage

Let learn how to use async/await through example 
```javascript
function getName(){
    return new Promise(resolve,reject) {
        setTimeout(()=>{
            console.log("HaiDV7")
        },1000)
    } 
}

async function example(){
    try {
        let result =  await getName()
        return result
    } catch (err) {
        console.log(err)
    }

}
example().then(result => console.log(result)).catch(err => console.log(err))
```