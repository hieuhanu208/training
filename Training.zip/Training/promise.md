# Promise
In ES6, to prevent the painless of callback hell, we has a Promise
Below is example for a  Promiese
```
let promiseExample = (name) => {
    return new Promise((resolve, reject)=>{
        setTimeout(()=>{
            if (typeof name !== 'undefined' && name) {
                reject("name is not defined")
            }
            resolve(name)
        },1000)
    })
}
```
 A promise has 2 parameter is resolve and reject. Resolve wil hanlde when you define your function is run exactly, the resolve function accept one parameter which is used later, and the reject, in contract, is used when you mean that thare are error while processing code. It also accept one parameter which is used later

```
promiseExample("gemini)
.then(name => console.log(name))
.catch(err => console.log(err))
```

The variable in then function is the paramenter we pass in resolve and the err in catch scope is the variable we pass the reject. If right, the console will be gemini