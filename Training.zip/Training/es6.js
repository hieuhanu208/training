// Variable Declaration


let  foo = (x,y,...a) => {
    return (x + y) * a.length
}

foo(1,2,3) === 9 