# TDD: test-dirven development

In summary
* Develoer viet cac test case  cho cac requirement  => chay thu => that bai => vi chua dc iplement
* Dua vao expectation, implement code
* Chay test
    - neu that bai, implement lai => cho den khi thanh cong
    - thanh cong => next
* Neu thanh cong, refector code: add comment, remove redundatn, varaible ...

The diagram below to show you to proceess of TDD

![TDD](http://vntesters.com/wp-content/uploads/2014/07/Missing-step-in-Test-Driven-Development-2.gif)
**Advantages**
* Co cai nhin truc quan ve san pham trc khi xay dung ma nguon
* Han che du thua, kha nang xay ra loi tren nhung phan du thua
* Bao dam ma nguon luon phan anh dung va vua du yeu cau phan mem