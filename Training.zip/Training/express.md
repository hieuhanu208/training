# Express
____
![Express JS Framework](http://mean.io/wp-content/themes/twentysixteen-child/images/express.png)
## Introduction
 Express is fast, unopinionated minimalist web framework for Node JS
## Installing
```
npm install express
```

## Create server
```
var express = require('express)
var app = express()
var port = process.env.PORT || 3000
app.listen(port, function (){
    console.log("Sever is already at http://%s:$d, app.get('domain'), app.get('port'))
})

```

## Hello Word
```
var express = require('express)
var app = express();
app.get('/', function(req,res) => {
    res.send("Hello World")
})
app.listen(3000, function (){
    console.log("Sever is already at http://%s:$d, app.get('domain'), app.get('port'))
})

```
## Routing in Express
____
### Route methods
```
var express = require('express')
var app = express()

app.get('/', function(req,res){
     res.send("Hello GET method")
})
app.post('/', function(req,res){
     res.send("Hello POST method")
})
app.put('/', function(req,res){
     res.send("Hello PUT method")
})
app.patch('/', function(req,res){
     res.send("Hello PATCH method")
})
app.delete('/', function(req,res){
     res.send("Hello DELETE method")
})
app.all('/all', function(req,res){
    res.send("All method is accepted here")
})

```
#### Route path
This route path will match the root route /
```
app.get('/', function(req,res){
     res.send("This is the root route")
})
```
 This route path will be match /contact
 ```
 app.get('/contact', function(req,res){
     res.send("This is contact route ")
})
```
##### _Regular Expression_ in route path
Route path can be written as regular experession
Let see the below examples
This route will be match /foobar or fobar
```
app.get('/foo?bar',function(req,res){
    res.send(foo?bar)
})
```
#### Route parameter
Let see the example
app.get('/user/:userId, function(req,res{
    res.send("user id is: " + req.params.userId)
}))

#### express.Router (read on docs)

### Middleware
#### Application-level middleware
For example, we need aceess the auth user in every views
```
app.use(req,res,next) {
    res.local.user = req.user;
    next()
}
```
#### Route-level midddleware
````
let Logger = function (req,res,next) {
    console.log(req)
    next()
}

app.get('/user', Logger, function (req,res){
    res.send("Middleware in route")
})

````

#### Error-handling middleware

app.use(function(err,req,res,next){
    console.log(err)
})

#### Third-party Middleware
See the docs of them: cookie-parser, bodt-parser, passport and so on

### Template Engine
To use template engine like HanldeBar,Pug and so on, follow this guide
```
    //Install your template engine
    npm install <TEMPLATE_ENGINE_NAME>

    //In your express app

    app.set('view engine', 'pug')
```