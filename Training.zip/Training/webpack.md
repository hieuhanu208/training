# Webpack

## Structure
``` javascript

 // wepback.config.js
var path = require('path')

module.exports = {
    entry: './entry.js, // entry to bundle
    ouput: {
        path: path.resolve(__dirname,'/dist')
        publicPath: '/dist/',
        filename: 'bundle.js'
    },
    module: {
        rules:[
            {
                test: /\.js$/,
                loader: 'babel-loader'
            }
        ]
    },
    resolves: {
        alisas: {
            '@components': './../components',
        },
        extensions: ['.js']
    },
    devtool: 'i#eval-source-map',
    plugins: [
        // plugin here
    ],
    devServer: {
        historyApiFallback: true,
        noInfo: true
    }
}
```
## Awesome Webpack Plugin
### HtmlWebpackPlugin
Generate index.html and inject bundle into body
Example 
```javascript
...
plugins: [
    new HtmlWebpackPlugin({
        name: 'index.html',
        templtate: 'index.html',
        inject: 'body'
    })
]
```
### ExtractTextWebpackPlugin
Extract and Chunk css/scss into css file
```javascript
...
module:{
    rules:[
    {
        test: /\.css$/,
        loader: ExtractTextPlugin.extract("style-loader", "css-loader")
    },
    // other loaders here
    ]
},
plugins: [
    new ExtractTextPlugin("[name].css")
],
...
```
### UglifyJsPlugin
```javascript
plugins: [
    new webpack.optimize.UglifyJsPlugin({
      sourceMap: true,
      compress: {
        warnings: false
      }
    })
]
```
### LoaderOptionsPlugin
```javascript
plugins:[
    new webpack.LoaderOptionsPlugin({
      minimize: true
    })
]
```

## Loaders
### Babel Loader
Use .babelrc to config
Example config file
```javascript
   {
    "presets": [
        [
            "es2015",
            {
                "modules": false
             }
        ]
    ],
    plugins: ['transform-runtime']
}
```
### ts-loader
use tsconfig.json to config
Example
```javascript
{
    "compilerOptions": {
      "sourceMap": true,
      "target": "es2015"
    }
}
```
### css-loader,style-loader,scss-loader
For example
```javascript
    ...
    module: {
        rules: [
            {
                test: /\.css$/,
                loaders:['style-loader','css-loader']
            },
             {
                test: /\.scss$/,
                loaders:['style-loader','css-loader!scss-loader']
            }
        ]
    }
```
### url-loader, filer-loader

