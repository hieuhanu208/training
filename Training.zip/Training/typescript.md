# Typescript
## Variable Declarations

``` typescript
let hello: string  = 'Hello World'
let a: number = 2
let isExist: boolean = true
let student = { name: string, age?: number }

function add(x: number, y: number): number {
    return x + y
}
```
## Interfaces
Like Java
``` typescript
    inteface Animal{
        eat(): void
    }

    class Dog implement Animal {
        eat(){
            console.log("Dog eat bone")
        }
    }
```

## Classes
Like Java
``` typescript
class Animal {
    name: string;
    constructor(theName: string) { this.name = theName; }
    move(distanceInMeters: number = 0) {
        console.log(`${this.name} moved ${distanceInMeters}m.`);
    }
}

class Snake extends Animal {
    constructor(name: string) { super(name); }
    move(distanceInMeters = 5) {
        console.log("Slithering...");
        super.move(distanceInMeters);
    }
}
```
### Modifier
#### Public
``` typescript
class Animal {
    public name: string;
    public constructor(theName: string) { this.name = theName; }
    public move(distanceInMeters: number) {
        console.log(`${this.name} moved ${distanceInMeters}m.`);
    }
}
```
#### Private

``` typescript
class Animal {
    private name: string;
    constructor(theName: string) { this.name = theName; }
}

new Animal("Cat").name; // Error: 'name' is private;
```

#### Protected
``` typescript
class Person {
    protected name: string;
    protected constructor(theName: string) { this.name = theName; }
}

// Employee can extend Person
class Employee extends Person {
    private department: string;

    constructor(name: string, department: string) {
        super(name);
        this.department = department;
    }

    public getElevatorPitch() {
        return `Hello, my name is ${this.name} and I work in ${this.department}.`;
    }
}

let howard = new Employee("Howard", "Sales");
let john = new Person("John"); // Error: The 'Person' constructor is protected
```

### Abstract Class
``` typescript
abstract class Department {

    constructor(public name: string) {
    }

    printName(): void {
        console.log("Department name: " + this.name);
    }

    abstract printMeeting(): void; // must be implemented in derived classes
}

class AccountingDepartment extends Department {

    constructor() {
        super("Accounting and Auditing"); // constructors in derived classes must call super()
    }

    printMeeting(): void {
        console.log("The Accounting Department meets each Monday at 10am.");
    }

    generateReports(): void {
        console.log("Generating accounting reports...");
    }
}
```
### Using a class as an interface
``` typescript
class Point {
    x: number;
    y: number;
}

interface Point3d extends Point {
    z: number;
}

let point3d: Point3d = {x: 1, y: 2, z: 3};
```
## Function
``` typescript
function add(x: number, y: number): number {
    return x + y;
}

let myAdd = function(x: number, y: number): number { return x+y; };
```

## Module
### Export
``` typescript
 // Validation.ts

export interface StringValidator {
    isAcceptable(s: string): boolean;
}
// ZipCodeValidator.ts

export const numberRegexp = /^[0-9]+$/;

export class ZipCodeValidator implements StringValidator {
    isAcceptable(s: string) {
        return s.length === 5 && numberRegexp.test(s);
    }
}
```
#### Export statement 
``` typescript
class ZipCodeValidator implements StringValidator {
    isAcceptable(s: string) {
        return s.length === 5 && numberRegexp.test(s);
    }
}
export { ZipCodeValidator };
export { ZipCodeValidator as mainValidator };
```

### Module resolution
``` typescript
 ModuleA.ts

class ExampleOne {
    doSomething() {
        return 5;
    }
}

export = ExampleOne;
ModuleB.ts

class ExampleTwo {
    doSomething() {
        return 'str';
    }
}

export = ExampleTwo;
// To make this work, you would create your ModuleA.d.ts:

// ModuleA.d.ts
declare class ExampleOne {
    doSomething(): number;
}
// And then reference it like so:

/// <reference path="modulea.d.ts" />

import B = require('moduleb');

var a = new ExampleOne();
var b = new B();
```