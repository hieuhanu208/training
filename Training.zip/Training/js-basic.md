# Variable
```
var name = "HaiDV7"
```
# Object
## Object definition
```
    var student = { name:"HaiDV", class: "2C13"}
```
## Access object properties
```
    var student = { name:"HaiDV", class="2C13" }
    console.log(student.name)
    // or
    console.log(student["name"])
```

## Method in object
```
    var student = {
        name: "HaiDV7",
        getName: function(){
            return this.name
        }
    }
    student.getName
```
# Array
## Array Definition
```
    var myArr = [1,2,3,4]
```
## Access array element
```
    var myArr = [1,2,3,4]
    console.log(myArr[1])
    console.log(myArr.length)
```
# Operator
|Operator|Exaplanation|Symbol|Example|
|---|---|---|---|
|Addtion|add two numbert together or two string|+| 6 + 9; "Hello" + "World"
|Substraction| Substraction in math| - | 9-6
|multiplication| multiple two numbers| *| 9*2
|Division| division in math| /| 8/2
|Assignment| Assign value to variable| =| var pi=3.14
|Equality| To test two value are equal or not, return true/false|===| var pi = 3.14; pi === 3.14

# Conditional
```
var myScore =5;
if (myScore <5) {
    alert("bad");
} else if (myScroe <8) {
    alert("good);
} else {
    alert("excelent")
}
```

# Switch
```
var myScore = 5;
switch (myScore){
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
        alert("bad");
        break;
    case 6:
    case 7:
    case 8:
        alert("good);
        break;
    case 9:
    case 10:
        alert("Excellent")'
        break;
}
```

# Loop
```
var myLatop = ['Asus', 'MacBook', 'Dell']

for (i = 0; i < myLaptop.length; i++) {
    console.log(mylaptop[i])
}
```

# Function
```
function add(a,b) {
    return a + b
}
add(2,3)
```

# Event
## onClick
```
document.querySelector('#myBtn').onClick = function(){
    alert("You clicked me")
}
```
Besides, there are many event: onchange, onsubmit, onkeydown, onmouseover so on 
