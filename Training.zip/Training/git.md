# GIT
## What is Git
Git is version control system

## Usage
### Intialize
```
git init
```
### Create repo
Crete reop on your Git and get the remote url
### Add remote into existing project
```
git remote add <REMOTE_NAME> <REMOUTE_URL>
```

### Commit
#### Add file changes
There are some option in add file change in git
```git
//Add all file which new or be modifed 
git add .
//Add all file which is new or be modified/deleted
git add -A
// Add all file changge which is modified or delted
git add *

```
#### Commit
```git
git commit -m <YOUR_MESSAGE>
```
### Push
```
git push <REMOTE_NAME> <TARGET_BRANCH>
````
### Pull
```
git pull <REMOTE_NAME> <TARGET_BRANCH>
``` 
### Branch
#### Checkout  new branch
```
git checkout -b <BRANCH_NAME>
```
#### Checkout existing branch
```
git checkout <BRANCH_NAME>
```
### Rebase 
```
git rebase <TARGET_BRANCH>
```
_Note_ : If conflict, you must to resolve it and run _git rebase --continue_ after that remember to push commit what you have changed
### Log
To display the log include the head (sum)
```
git log  ---oneline
```
### Reset to specified head
```
git reset --hard <HEAD>
```
### Show diff
```
git diff
```

### Merge
```
git merge <BRANCH_TARGET>
```
### Fetch from remote
```
git fetch <REMOTE_NAME>
```


