# NPM
___
## What is NPM
NPM stands for node package manage.Therefore, it 's package manager (like compose of PHP). It help to reuse code, share pacakage and so on

##  Installing packages
### Locally 
To install paackage in local project, we use below command:
```
npm install <PACKAGE_NAME>
```
With NPM5, no need flag --save. If you want save package in devDependencies just add flag -D or --save-dev
_Note_: In default, NPM will install all pacakges from package.json include dependencies and devDependcies. If you only want to install depency, npm install --production
### Globally 
```
npm install -g <PACKAGE_NAME>
```
## Package.json file explanation
To init , run
```
npm init
```
_Note_: Add flag -Y for default information to init package.jsom
Struture of package.json
```
name: "",
description: "",
version: "",
main: "",
scripts: {},
repository: {
    type: "",
    url:"",
},
keywords:[],
author:"",
licensce:"",
```
In this I only focus on scipts because this is where you can define your own script, it is very useful

## Updating
```
npm update
```
## Uninstalling
### Local
```
npm unistall <PACKAGE_NAME>
```
### Global

```
npm uninstall -g <PACKAGE_NAME>
```
## Listing
To listing packages which is installed, just run
```
npm ls
```




