# Unit Test

# Definition: 
to test small part of application, it can be function, module or class. However it is case that this is alwasy be a function
A unit test is not related others like network, databases => To handle this, use third-party to fake

#