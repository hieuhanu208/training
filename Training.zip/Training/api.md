# API
Let write the most simple REST API in nodejs by using express framework
## Prerequisite:
- NodeJS
- Module: express,body-parser.

## Install
Create package.json:
```
    npm init -Y
```
Then install depenedncies
```
    npm install express body-parser
```
## Config Express App
Create sever.js and this will be like
```
    var express = require('express')
    var app = express()
    var bodyParser = require("body-parser");
    var port = process.env.PORT || 3000
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

    app.get('/book', function(req,res){
        res.json({ name: "Code Complete", price: 20 }).status(200)
    })
    app.post('/book', function(req,res){
        res.json({ name: req.body.name, price: req.body.price }).status(200)
    })

    app.listen(port, function(){
        console.log("Your API is already to test")
    })

```
_Note_: For other methods like PUT/PATCH,DELETE or ANY, you can use the same way

## Test API
Now you can use Postman to test your API and if succesfully you will get the json resull.

## Advanced
### Authentication
Use can use passport-jwt with jsonwebtoken to genrerate token for user. Dont forget the expiration