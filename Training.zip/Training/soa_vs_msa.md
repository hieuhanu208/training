# SOA vs MSA

![soa vs msa](http://blogs.bmc.com/wp-content/uploads/2017/05/SOA-architecture-vs-microservices.jpg)

|soa|msa|
|---|---|
|Built on the idea of “share-as-much-as-possible” architecture approach|Built on the idea of “share-as-little-as-possible” architecture approach|
|More importance on business functionality reuse|More importance on the concept of “bounded context”
|Common governance and standards|Relaxed governance, with more focus on people collaboration and freedom of choice
|Uses enterprise service bus (ESB) for communication|Uses less elaborate and simple messaging system|
|Supports multiple message protocols|Uses lightweight protocols such as HTTP/REST & AMQP
|Common platform for all services deployed to it|Application Servers not really used. Platforms such as Node.JS could be used
|Multi-threaded with more overheads to handle I/O	|Single-threaded usually with use of Event Loop features for non-locking I/O handling
|Use of containers (Dockers, Linux Containers) less popular|Containers work very well in MSA
|Maximizes application service reusability|	More focused on decoupling
|Uses traditional relational databases more often|Uses modern, non-relational databases
|A systematic change requires modifying the monolith|A systematic change is to create a new service
|DevOps / Continuous Delivery is becoming popular, but not yet mainstream|	Strong focus on DevOps / Continuous Delivery