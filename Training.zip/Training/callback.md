# Callback 
Let define yor callback through example
```
function myInfoCb(name,age,cb) {
    if (typeof name !== undefined && name  &&
        tyoeof age ! == undefined && age ) {
            cb(name,age);
        }
    let err = "SOmething went wrong"
    cb(undefined,undefined,err)
}

myInfoCb("HaiDV7",17,function(name,age,err){
    if (err) console.log(err)
    console.log("my name is ${name} and my age is ${age}")
}) 
```
It easy to understand. Right ????