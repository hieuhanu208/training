# File
To work with file in NodeJS, we use build-in module fs
```
var fs = require('fs')
```

There are two mode work with file in fs modlue: synchnorous vs asynchnorous. It's better to use asynchnorous mode
Let see the example

Create new file hello_world.txt
```
    //hello_world.txt
    Hello World!
```

Let read this file in two diffent modes 
