Dear Mr Luu,
Below is my daily report on 10-08-2017

_Daily Report_

|STT|Content| Status|Problem
|---|---|---|---|
1|[General] Javscipt Basic|Complete|None
2|[General]ES6|Complete| Difficlut in understand the concept of proxying althought it like __call method in PHP
3|[General]Git|Complete| None
4|[NodeJS]npm|Complete|None
5|[NodeJS] Evenet-loop,sync/async, await,promise,callback|On progress| difficult to approach the concept of event-loop. Complete understand async/await, callback, promise
6|[NodeJS] Module:Express|comlete|none
7|[NodeJS] Routing|on progress|
8|[NodeJS] REST API| on progress| none

For detailed result, you can see which I got in attach files.

Thanks

Sincerely,
HaiDV7